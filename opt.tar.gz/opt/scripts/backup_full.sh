#!/bin/bash

# backup_full.sh
# Script para realizar backups con nombre que incluye fecha ANSI (YYYYMMDD)
# Uso: backup_full.sh -o <origen> -d <destino>
# Opciones: -help para mostrar ayuda

show_help() {
    echo "Uso: $0 -o <directorio_origen> -d <directorio_destino>"
    echo
    echo "Opciones:"
    echo "  -o       Directorio origen a respaldar"
    echo "  -d       Directorio destino donde se guardará el backup (debe estar montado)"
    echo "  -help    Mostrar esta ayuda"
    echo
    echo "Ejemplo:"
    echo "  $0 -o /var/log -d /backup_dir"
}

# Validar argumentos
if [[ $# -eq 0 ]]; then
    echo "Error: No se especificaron argumentos."
    show_help
    exit 1
fi

while [[ $# -gt 0 ]]; do
    case "$1" in
        -o)
            ORIGEN="$2"
            shift 2
            ;;
        -d)
            DESTINO="$2"
            shift 2
            ;;
        -help)
            show_help
            exit 0
            ;;
        *)
            echo "Opción desconocida: $1"
            show_help
            exit 1
            ;;
    esac
done

# Validar que origen y destino estén definidos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe especificar directorio origen y destino."
    show_help
    exit 1
fi

# Validar que origen exista y sea un directorio
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio origen '$ORIGEN' no existe o no es un directorio."
    exit 1
fi

# Validar que destino exista y sea un directorio
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: El directorio destino '$DESTINO' no existe o no es un directorio."
    exit 1
fi

# Validar que origen y destino estén montados
if ! mountpoint -q "$ORIGEN"; then
    echo "Advertencia: El directorio origen '$ORIGEN' no parece estar en un sistema de archivos montado."
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: El directorio destino '$DESTINO' no está montado. Abortando backup."
    exit 1
fi

# Obtener nombre base del directorio origen para el archivo backup
BASENAME=$(basename "$ORIGEN")

# Obtener fecha en formato YYYYMMDD
FECHA=$(date +%Y%m%d)

# Nombre del archivo backup
ARCHIVO_BKP="${BASENAME}_bkp_${FECHA}.tar.gz"

# Ruta completa del archivo backup
RUTA_BKP="${DESTINO}/${ARCHIVO_BKP}"

# Ejecutar backup
echo "Realizando backup de '$ORIGEN' en '$RUTA_BKP'..."
tar -czf "$RUTA_BKP" -C "$(dirname "$ORIGEN")" "$BASENAME"

if [[ $? -eq 0 ]]; then
    echo "Backup realizado correctamente."
    echo "Archivo generado: $RUTA_BKP"
else
    echo "Error al realizar el backup."
    exit 1
fi


